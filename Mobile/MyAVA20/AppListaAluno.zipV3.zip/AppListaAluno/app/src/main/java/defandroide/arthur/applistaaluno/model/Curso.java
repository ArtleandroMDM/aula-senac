package defandroide.arthur.applistaaluno.model;

public class Curso {

    private String CursoDesejado;

    public Curso(String CursoDesejado) {
        this.CursoDesejado = CursoDesejado;
    }

    public String getCursoDesejado() {
        return CursoDesejado;
    }

    public void setCursoDesejado(String cursoDesejado) {
        CursoDesejado = cursoDesejado;
    }

}
