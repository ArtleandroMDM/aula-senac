package defandroide.arthur.applistaaluno.Controller;

public class CursoController {
}
